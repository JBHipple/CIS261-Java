// Joshua Hipple
// CIS 261 - W1
// Final Exam - Question 1
// Question 1 test application

import javax.swing.*;

public class Final1
{
	public static void main(String[] args)
	{
		Calculator calcWindow = new Calculator();
		calcWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		calcWindow.setSize(220, 185);
		calcWindow.setVisible(true);
	}
}